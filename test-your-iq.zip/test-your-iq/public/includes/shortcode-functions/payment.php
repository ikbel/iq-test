<?php

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

//Get basic variables
$iq_client_id = get_option('iq-client-id');
$iq_price = get_option('iq-price');
$iq_currency = get_option('iq-currency');
$iq_pay_description = get_option('iq-pay-description');
$iq_pay_short_text = get_option('iq-pay-short-text');
$iq_pay_headline = get_option('iq-pay-headline');
$iq_payment_description = get_option('iq-payment-description');
$iq_pay_amount_text = get_option('iq-pay-amount-text');

$ajax_url = admin_url('admin-ajax.php');



$html .= '<div class="iq-test-wrap" id="iq-test-paypal">';
$html .= '<div class="iq-test-pad">';
$html .= '<div class="iq-test-header">';
$html .= '<div class="iq-congratulation">'.$iq_pay_short_text.'</div>';
$html .= '<div class="iq-congratulation qresult">'.$iq_pay_headline.'</div>';
$html .= '<div class="iq-clear"></div>';
$html .= '</div>';
$html .= '<div class="iq-ev">'.$iq_payment_description.'</div>';
$html .= '<div class="iq-testid">'. esc_attr__('ID of the Test:', 'test-your-iq').' '.$test_id.'</div>';
$html .= '<div class="iq-correctanswers">';
$html .= '<div class="iq-fee-test">'.$iq_pay_amount_text.' - '.$iq_price.' '.$iq_currency.'</div>';
$html .= '<div class="iq-clear"></div>';


$html .= '<div id="smart-button-container">';
$html .= '<div style="text-align: center;">';
$html .= '<div id="paypal-button-container"></div>';
$html .= '</div>';
$html .= '</div>';

$html .= '<div class="iq-clear"></div>';
$html .= '</div>';
$html .= '<div class="iq-clear"></div>';
$html .= '</div>';
$html .= '</div>';


$html .= "<script>

        function initPayPalButton() {
            paypal.Buttons({
                style: {
                    shape: 'rect',
                    color: 'gold',
                    layout: 'vertical',
                    label: 'pay',
    
                },
    
                createOrder: function (data, actions) {
                    return actions.order.create({
                        purchase_units: [{\"description\": \"$iq_pay_description\", \"amount\": {\"currency_code\": \"$iq_currency\", \"value\": $iq_price}}]
                    });
                },
    
                onApprove: function (data, actions) {
                    return actions.order.capture().then(function (details) {
                        jQuery('#iq-test-paypal').hide();
                        jQuery('#iq-test-result').show();
                        
                        payment_save_data();
                    });
                },
    
                onError: function (err) {
                    console.log(err);
                }
            }).render('#paypal-button-container');
        }
        
        initPayPalButton();
            
        function payment_save_data(){
            var data = {
                action: 'iq_after_payment',
                testid: '$test_id',
            };
            var ajaxurl = '$ajax_url';
            jQuery.post(ajaxurl, data);
         
        }

</script>";




