Installation

= Uploading in WordPress Dashboard =

Unpack archive from Codecanyon.net
Navigate to the ‘Add New’ in the plugins dashboard
Navigate to the ‘Upload’ area
Select `iq-test.zip` from your computer
Click ‘Install Now’
Activate the plugin in the Plugin dashboard
= Using FTP =

Unpack archive from Codecanyon.net
Open`iq-test.zip`
Extract the `iq-test`directory to your computer
Upload the `iq-test` directory to the `/wp-content/plugins/` directory
Activate the plugin in the Plugin dashboard
= After Plugin Activation =

Create a Page (not Post) to display the IQ test and enter this shortcode there:
[iq-test]
In admin, you will see `IQ Test` on the left. This is the administration panel for the test.
Set the default settings for your IQ Test
Done!